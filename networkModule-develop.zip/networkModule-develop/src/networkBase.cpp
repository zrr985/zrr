#include "netWorkBase.hpp"
netWorkBase::netWorkBase(struct ipPort _sourceIpPort) : sourceIpPort_{_sourceIpPort}{};

netWorkBase::~netWorkBase()
{
    
}